four51.app.controller('OrderTypeSelectorCtrl', ['$scope', function ($scope) {

}]);