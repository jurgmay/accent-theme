four51.app.directive('giftcardredemption', function() {
	var obj = {
		restrict: 'E',
		templateUrl: 'partials/controls/giftCardRedemption.html',
		controller: 'GiftCardRedemptionCtrl'
	};
	return obj;
});