four51.app.directive('orderapprovals', function() {
	var obj = {
		restrict: 'AE',
		templateUrl: 'partials/controls/orderApprovals.html'
	};
	return obj;
});