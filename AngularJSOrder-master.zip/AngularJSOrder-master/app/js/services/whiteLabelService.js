four51.app.factory('WhiteLabel', function() {
	var replacements = [];
	return { replacements: replacements };
});